/**
 * Suit enums
 * @author Mikael Hinton
 *
 */
public enum Suit {
	
	Diamonds,
	Hearts,
	Clubs,
	Spades;
}//EOF
